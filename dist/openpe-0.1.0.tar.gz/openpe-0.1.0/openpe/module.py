
def example_function():
    return "Hello, World!"