
import unittest
from openpe.module import example_function

class TestModule(unittest.TestCase):
    def test_example_function(self):
        self.assertEqual(example_function(), "Hello, World!")

if __name__ == '__main__':
    unittest.main()